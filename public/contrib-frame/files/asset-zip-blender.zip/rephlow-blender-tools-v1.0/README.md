# rePhlow Blender tools

Seven Python scripts for Blender, written while modelling the rePhlow
bioreactor and released so that another team does not have to write them
again.

**rePhlow, iGEM UCM Madrid 2026** · MIT Licence · Tested in Blender [version to fill in]

Project page: https://2026.igem.wiki/rephlow/contribution

---

## What is here

| # | File | What it solves |
|---|------|----------------|
| 1 | `01_procedural_hydrogel_generator.py` | A hydrogel bead with a procedural core-shell material. Cloudy core, transmissive shell, no texture images. |
| 2 | `02_procedural_perforated_mesh.py` | A hexagonal mesh with micro-perforations wrapped around a cylinder, using alpha instead of geometry. No vertices added. |
| 3 | `03_macro_studio_lighting_rig.py` | Three-point lighting and a tracking camera calibrated for objects measured in millimetres. |
| 4 | `04_optimized_particle_instancing.py` | Many particles sharing one mesh and one material, so a full container does not freeze the viewport. |
| 5 | `05_parametric_hardware_engraving.py` | A complete device built from code, with procedural knurling and text carved into a curved surface. |
| 6 | `06_procedural_mesh_slicer.py` | Slicing a mesh at an exact height with `bmesh.ops.bisect_plane`, for exploded views and opening mechanisms. |
| 7 | `07_automated_infinite_rotation.py` | A seamless rotation loop, with linear interpolation so there is no acceleration artefact at the ends. |

Scripts 1 to 3 solve problems most teams modelling biotechnology hardware
will meet. Scripts 4 to 7 need adapting to a given project but contain
reusable Blender Python techniques.

## How to run them

**Recommended.** Open the Scripting workspace in Blender, create a new text
block, paste the whole file and press Run Script, or `Alt + P`.

The Python console works for short commands but is uncomfortable for a full
script. An external terminal cannot run these at all on its own: they
`import bpy`, which only exists inside Blender's own Python environment.
Launching Blender in background mode with `--python` does work.

No external libraries are required. Nothing needs installing beyond Blender.

## Scene requirements

This matters. Several scripts act on objects created by the others, because
they were written as a chain rather than as isolated utilities. Read this
before reporting that one of them does nothing.

| # | Needs in the scene |
|---|--------------------|
| 1 | Nothing. Runs on an empty scene. |
| 2 | An object named `Base_Principal` or `Cuerpo_Acero`. |
| 3 | `Empty_Rotacion` or `Cuerpo_Acero` as an aim target. Deletes every existing camera and light. |
| 4 | `Basket_Body`. Run script 6 first. |
| 5 | Nothing. This is the script that creates `Cuerpo_Acero` and `Tapon_Laton`. |
| 6 | `Cuerpo_Acero`, and `Empty_Rotacion` if you want the pieces parented. |
| 7 | `Cuerpo_Acero` and `Tapon_Laton`. |

To reproduce the full rePhlow assembly, run them in this order:
**5 → 2 → 7 → 6 → 4 → 3**, with 1 at any point as a standalone test.

To reuse a single technique on your own model, rename your object to the
name the script expects, or edit the lookup at the top of the file. Every
script states which names it looks for.

## Scale convention

The scene uses 1 Blender Unit = 1 millimetre, set through
`scene.unit_settings.scale_length = 0.001`. That changes how units are
displayed, not how light is computed: Cycles and EEVEE still treat one unit
as one metre. This is why the lamp energies in script 3 are in the tens of
millions of watts. They are calibrated, not mistaken.

## Licence

MIT. See `LICENSE`. You may use, modify and redistribute these scripts,
inside or outside iGEM, provided the copyright notice is kept. Each file
carries the notice in its header, so the licence travels with a script that
is copied on its own.

They were written by combining our own 3D modelling experience with AI
assistance for the harder problems, specifically mechanical animation and
procedural materials. Every script was then run, corrected and used to
produce the renders published on the project wiki, so what is released here
is working code rather than generated code.

Provided as they are, without warranty.
