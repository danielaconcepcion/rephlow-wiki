# Part documentation — Genetic engineering parts

Paste each block into the part's **Documentation → Create** entry and pick the **Type** indicated.
Honest-data policy: the only experimental validation in this branch is the ~1.7-fold accumulation-rate increase for the EM7-RBS-ppk1 cassette on pSEVA2513. Every other part is designed, codon-optimised/assembled and sequence-verified but **was not experimentally validated in this project**; that is stated plainly rather than invented.

---

## ppk1 — BBa_267JZVK9 · Type: Design

- **Importance & use:** Polyphosphate kinase 1 (EC 2.7.4.1) polymerises the terminal phosphate of ATP into inorganic polyphosphate (polyP) — the storage half of rePhlow's phosphorus-recovery phenotype, giving *P. putida* a PAO-like (polyphosphate-accumulating) behaviour. Reuse it whenever you want intracellular polyP accumulation in a Gram-negative host.
- **Design & prior work:** Based on *ppk1* from *Candidatus* Accumulibacter phosphatis, the organism behind enhanced biological phosphorus removal in wastewater. The CDS was codon-optimised for *Pseudomonas putida* and designed to run under the constitutive EM7 promoter + a canonical *P. putida* RBS.
- **DNA source:** Gene synthesis of the codon-optimised sequence (the native organism is unculturable, so not PCR-amplified).
- **Problems:** None obtaining the synthetic DNA.
- **Testing recommendations:** Express in *P. putida* KT2440; quantify polyP (DAPI fluorescence shift) or Pi depletion from the medium vs an empty-vector control.
- **Experiment & controls:** Provided as a CDS and assembled into the EM7-RBS-ppk1 cassette (BBa_26RWV88W); sequence-verified.
- **Data:** The functional effect of this CDS was characterised in the **EM7-RBS-ppk1 cassette (BBa_26RWV88W)**, where it raised the accumulation rate ~1.7-fold; see that part's Characterisation entry. The CDS itself is sequence-verified.

---

## EM7-RBS-ppk1 cassette — BBa_26RWV88W · Type: Characterisation

- **What we measured:** In *P. putida* carrying this cassette on pSEVA2513 (pS2513ppk1), the phosphate/polyphosphate **accumulation rate was ~1.7-fold higher than the control strain** — the only quantitative functional validation in rePhlow's genetic-engineering branch.
- **Conditions:** [specify medium, phosphate concentration, temperature and the time window used to estimate the rate].
- **Controls:** [empty-vector / wild-type *P. putida* — confirm which]; same growth conditions.
- **Importance & use:** A ready-to-use constitutive expression cassette (EM7 promoter + canonical *P. putida* RBS + codon-optimised ppk1) that installs polyP storage in one step. Reuse it to confer polyphosphate accumulation on a Gram-negative host.
- **Design & prior work:** EM7 constitutive promoter (reused part BBa_K4278705) + canonical *P. putida* RBS + ppk1 (*Ca.* Accumulibacter, codon-optimised); assembled in the broad-host-range pSEVA2513 backbone.
- **DNA source:** Component synthesis + assembly; EM7 added via complementary oligos with Type IIS (BsaI)-compatible overhangs.
- **Problems / notes:** RBS→ATG spacing came out ~13 nt (short poly-A tail) vs the canonical 6–8 nt; expression was not impaired (the 1.7× result confirms a functional cassette), but trim the tail for tighter spacing.
- **Limitations / future work:** Single functional read-out (rate); confirm with DAPI-polyP quantification and longer time-courses, and pair with the pstSCAB uptake cassette to test the complete phenotype.

---

## pstS — BBa_26S6YNNK · Type: Design

- **Importance & use:** Periplasmic, high-affinity phosphate-binding protein of the Pst ABC transporter; scavenges orthophosphate from the periplasm and delivers it to the membrane permease. The capture component of a high-affinity phosphate-uptake system.
- **Design & prior work:** From the *pstSCAB* operon of *Ca.* Accumulibacter phosphatis, codon-optimised for *P. putida*; part of the reconstituted Pst transporter that feeds polyP accumulation.
- **DNA source:** Gene synthesis (codon-optimised).
- **Problems:** None noted.
- **Testing recommendations:** Functional only as part of the complete transporter; test via the pstSCAB operon under phosphate limitation in *P. putida*.
- **Experiment & controls:** Provided as a CDS and as a component of the pstSCAB operon (BBa_26MFRRWR); sequence-verified.
- **Data:** Designed and sequence-verified; **not experimentally validated in this project** — functional characterisation remains for future work.

---

## pstC — BBa_267HLDGW · Type: Design

- **Importance & use:** Membrane permease subunit of the Pst high-affinity phosphate ABC transporter; forms the translocation channel with pstA. Reuse as part of a high-affinity Pi import module.
- **Design & prior work:** From *Ca.* Accumulibacter phosphatis *pstSCAB*, codon-optimised for *P. putida*.
- **DNA source:** Gene synthesis (codon-optimised).
- **Problems:** None noted.
- **Testing recommendations:** Functional only within the complete transporter; test via the pstSCAB operon in *P. putida*.
- **Experiment & controls:** CDS and component of the operon; sequence-verified.
- **Data:** Designed and sequence-verified; **not experimentally validated in this project** — functional characterisation remains for future work.

---

## pstA — BBa_26SD42UP · Type: Design

- **Importance & use:** Membrane permease subunit of the Pst transporter; forms the translocation channel with pstC. Reuse as part of a high-affinity Pi import module.
- **Design & prior work:** From *Ca.* Accumulibacter phosphatis *pstSCAB*, codon-optimised for *P. putida*.
- **DNA source:** Gene synthesis (codon-optimised).
- **Problems:** None noted.
- **Testing recommendations:** Test as part of the complete pstSCAB operon in *P. putida*.
- **Experiment & controls:** CDS and component of the operon; sequence-verified.
- **Data:** Designed and sequence-verified; **not experimentally validated in this project** — functional characterisation remains for future work.

---

## pstB — BBa_26EP8J8O · Type: Design

- **Importance & use:** Cytoplasmic ATPase subunit of the Pst transporter; hydrolyses ATP to power high-affinity phosphate import. The energising subunit of the Pi uptake module.
- **Design & prior work:** From *Ca.* Accumulibacter phosphatis *pstSCAB*, codon-optimised for *P. putida*.
- **DNA source:** Gene synthesis (codon-optimised).
- **Problems:** None noted.
- **Testing recommendations:** Test within the complete pstSCAB operon; ATPase activity is only meaningful in the assembled complex.
- **Experiment & controls:** CDS and component of the operon; sequence-verified.
- **Data:** Designed and sequence-verified; **not experimentally validated in this project** — functional characterisation remains for future work.

---

## pstSCAB operon — BBa_26MFRRWR · Type: Design

- **Importance & use:** The complete high-affinity phosphate ABC transporter (pstS + pstC + pstA + pstB) as a single transcriptional unit — the uptake half of rePhlow's recovery phenotype. Reuse it to give a Gram-negative host high-affinity Pi uptake in one part.
- **Design & prior work:** Codon-optimised *pstSCAB* from *Ca.* Accumulibacter phosphatis, assembled as one operon with Shine-Dalgarno spacing between CDSs; designed to pair with ppk1 (storage) for the full PAO phenotype. Gene order as assembled: pstC–pstA–pstS–pstB.
- **DNA source:** Gene synthesis of the codon-optimised operon; assembled into pSEVA6313.
- **Problems:** None obtaining the DNA.
- **Testing recommendations:** Express in *P. putida* KT2440 (as the EM7-RBS-pstSCAB cassette) under phosphate limitation; measure Pi depletion from the medium and, with ppk1, polyP accumulation (DAPI shift).
- **Experiment & controls:** Assembled and sequence-verified; recommended controls: empty vector and a ppk1-only strain.
- **Data:** Designed and sequence-verified; **not experimentally validated in this project** — functional characterisation remains for future work.

---

## EM7-RBS-pstSCAB cassette — BBa_26R5VIO0 · Type: Design

- **Importance & use:** A ready-to-use constitutive cassette that drives the complete high-affinity phosphate transport operon in *P. putida*, supplying orthophosphate for polyP accumulation. Reuse it to install high-affinity Pi uptake in one step.
- **Design & prior work:** EM7 promoter (reused BBa_K4278705) + canonical *P. putida* RBS + codon-optimised pstSCAB operon; assembled in pSEVA6313.
- **DNA source:** Component synthesis + assembly; EM7 cloned via annealed oligos with BsaI-compatible overhangs into pSEVA631 to build pSEVA6313, then the operon added.
- **Problems / notes:** Shares the ~13 nt RBS→ATG spacing note of the ppk1 cassette.
- **Testing recommendations:** Express in *P. putida* KT2440 under phosphate limitation; measure Pi depletion, and polyP accumulation when combined with the ppk1 cassette.
- **Experiment & controls:** Assembled and sequence-verified; controls: empty backbone, ppk1-only strain.
- **Data:** Designed and sequence-verified; **not experimentally validated in this project** — functional characterisation remains for future work.

---

## Canonical P. putida RBS — BBa_26JTTESY · Type: Design

- **Importance & use:** A canonical Shine-Dalgarno RBS for *P. putida* that provides translation initiation for downstream CDSs. Reuse as a standard RBS when building constitutive expression units in *Pseudomonas*.
- **Design & prior work:** Canonical *P. putida* SD sequence (`TGACCTAAGGAGGTAAATA`), placed upstream of the start codon in the EM7-RBS cassettes.
- **DNA source:** Short synthetic sequence, included by synthesis within the cassette constructs.
- **Problems / notes:** In the assembled cassettes the RBS→ATG spacing came out ~13 nt (short poly-A tail) rather than the textbook 6–8 nt; trim the tail for tighter spacing.
- **Testing recommendations:** Benchmark with a reporter (e.g., msfGFP) in *P. putida* for a relative translation-initiation strength.
- **Experiment & controls:** Used in two parts (EM7-RBS-ppk1 and EM7-RBS-pstSCAB); sequence-verified.
- **Data:** It supports expression in a functional cassette (the EM7-RBS-ppk1 cassette gave a ~1.7-fold accumulation-rate increase); a dedicated reporter-based RBS strength was **not measured in this project**.

---

## gRNA-ppx — BBa_26EP93V7 · Type: Design

- **Importance & use:** Guide RNA that directs the pMBEC2 cytidine base editor to *ppx* (exopolyphosphatase) in *P. putida* KT2440, installing a premature STOP (C→T) to inactivate it. Removing exopolyphosphatase limits polyP degradation, reinforcing accumulation. Reuse to knock out *ppx* markerlessly.
- **Design & prior work:** Spacer designed to place an editable C in the editing window so deamination creates a STOP (targeting CAA/CAG/CGA or complementary ACC), following the pMBEC2 / Volke et al. (2022) strategy.
- **DNA source:** Spacer introduced by PCR/oligo from the pEX128 gRNA template; scaffold and Csy4 hairpin are standard.
- **Problems:** None noted; the creditable design is the 20-nt spacer and target choice (scaffold is standard, hence common BLAST hits).
- **Testing recommendations:** Electroporate into *P. putida* KT2440 carrying the pMBEC2 editor; screen edits by colony PCR + Sanger sequencing of *ppx*.
- **Experiment & controls:** Assembled into the multiplexed array (BBa_26GX2W8D) and into pMBEC2 by BsaI Golden Gate; sequence-verified. Recommended control: non-targeting / empty-array editor.
- **Data:** Spacer and assembly sequence-verified; **editing not experimentally validated in this project** — knockout efficiency remains for future work.

---

## gRNA-ppkB — BBa_26X6EW3X · Type: Design

- **Importance & use:** Guide RNA directing the pMBEC2 base editor to *ppkB* in *P. putida*, installing a premature STOP (C→T) to disrupt PpkB activity. Reuse to knock out *ppkB* markerlessly.
- **Design & prior work:** Spacer designed to position an editable C for STOP-codon creation, per the pMBEC2 base-editing approach.
- **DNA source:** Spacer from the pEX128 template; standard scaffold + Csy4 hairpin.
- **Problems:** None noted.
- **Testing recommendations:** Electroporate into *P. putida* KT2440 with pMBEC2; confirm edits by colony PCR + sequencing of *ppkB*.
- **Experiment & controls:** In the multiplexed array and pMBEC2 (BsaI Golden Gate); sequence-verified. Control: non-targeting editor.
- **Data:** Spacer and assembly sequence-verified; **editing not experimentally validated in this project** — knockout efficiency remains for future work.

---

## gRNA-pitB — BBa_26GDVDZQ · Type: Design

- **Importance & use:** Guide RNA directing the pMBEC2 base editor to *pitB* (low-affinity phosphate transporter) in *P. putida*, installing a premature STOP (C→T) to inactivate it. Removing the low-affinity route favours retention via the high-affinity Pst system. Reuse to knock out *pitB* markerlessly.
- **Design & prior work:** Spacer designed for STOP-codon creation within the editing window, per the pMBEC2 strategy.
- **DNA source:** Spacer from the pEX128 template; standard scaffold + Csy4 hairpin.
- **Problems:** None noted.
- **Testing recommendations:** Electroporate into *P. putida* KT2440 with pMBEC2; confirm edits by colony PCR + sequencing of *pitB*.
- **Experiment & controls:** In the multiplexed array and pMBEC2 (BsaI Golden Gate); sequence-verified. Control: non-targeting editor.
- **Data:** Spacer and assembly sequence-verified; **editing not experimentally validated in this project** — knockout efficiency remains for future work.

---

## gRNA3 multiplexed array — BBa_26GX2W8D · Type: Design

- **Importance & use:** A single Csy4-processed array carrying the three guides (ppx, ppkB, pitB), so the pMBEC2 base editor can target all three phosphate-metabolism genes in one step — a markerless, multiplexed route to sharpen the polyP-accumulation phenotype. Reuse the array design for multiplexed base editing in *Pseudomonas*.
- **Design & prior work:** Three [Csy4 hairpin]–[20-nt spacer]–[scaffold] units in series; Csy4 (Cas6f) cleaves between units to release individual guides, following the pMBEC2 multiplex design (Volke et al., 2022). Unique 4-nt fusion overhangs set the assembly order.
- **DNA source:** The three guide fragments were generated by PCR from the pEX128 template and assembled in defined order into pMBEC2 by BsaI Golden Gate.
- **Problems:** None noted.
- **Testing recommendations:** Electroporate the pMBEC2-gRNA3 construct into *P. putida* KT2440; screen for simultaneous edits at all three loci by colony PCR + sequencing.
- **Experiment & controls:** Array assembled and verified by sequencing across the cloned guide region; controls: single-guide constructs and a non-targeting array. The editor is the published pMBEC2 (Addgene #187596; Volke et al., Nat Commun 2022, doi:10.1038/s41467-022-30780-z), cited as a tool, not registered.
- **Data:** Array sequence-verified; **multiplex editing not experimentally validated in this project** — efficiency remains for future work. (Reclassify this entry as *Application* once editing is demonstrated.)
